#ifndef  SCORE_H
#define  SCORE_H

#include "BaseData.h"

class Score: public BaseData{
public:
    Score(std::string _type):BaseData(_type){};
};


#endif