#ifndef PATH_H
#define PATH_H

#include <string>
#include <QDebug>

const std::string PATH="/tmp/infocollection/data/"; //各种txt  photos文件夹所在路径
const std::string WORKPATH="/tmp/infocollection/Catcher/"; //py文件所在路径



//test
//const std::string PATH="/home/monell/qtcode/build-InfoCS-Desktop_Qt_5_10_1_GCC_64bit-Debug/";
//const std::string WORKPATH="/home/monell/qtcode/InfoCS/Catcher/";


#endif // PATH_H
