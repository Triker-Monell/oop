#include "BaseCatcher.h"
BaseCatcher::BaseCatcher() {
    //base_object= nullptr;
}
BaseCatcher::~BaseCatcher() {
    //delete base_object;
}