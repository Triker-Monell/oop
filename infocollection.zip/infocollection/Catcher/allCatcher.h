#ifndef ALLCATCHER_H
#define ALLCATCHER_H

#include "BaseCatcher.h"

#include "Douban_by_movies.h"
#include "Douban_by_people.h"
#include "Douban_by_toplist.h"
#include "Douban_by_TV.h"



#include "IMDB_by_movies.h"
#include "IMDB_by_people.h"
#include "IMDB_by_toplist.h"
#include "IMDB_by_TV.h"



#include "RottenTomatoes_by_movies.h"
#include "RottenTomatoes_by_people.h"
#include "RottenTomatoes_by_toplist.h"
#include "RottenTomatoes_by_TV.h"





#endif
