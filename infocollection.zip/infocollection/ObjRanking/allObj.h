#ifndef ALLOBJ_H
#define ALLOBJ_H

#include "BaseObject.h"
#include "MovieObject.h"
#include "PersonObject.h"
#include "Ranking.h"
#include "TVObject.h"


#endif
