#include "qt_scorewidget.h"

ScoreWidget::ScoreWidget(QWidget *parent) : QWidget(parent)
{

}

ScoreWidget::~ScoreWidget(){

}
